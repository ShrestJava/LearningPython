Python 3.9.7 (tags/v3.9.7:1016ef3, Aug 30 2021, 20:19:38) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> def Function1(myname):
	print('Hello, my name is %s' % myname)

	
>>> Function1("Shrest")
Hello, my name is Shrest
>>> # 2 or more parameter function
>>> def Function2(firstname, lastname):
	print('Hello, my name is %s %s' % (firstname, lastname))

	
>>> Function2('Shrestajna', 'Burra')
Hello, my name is Shrestajna Burra
>>> # no parameters function
>>> integer1 = 37
>>> integer2 = 89.9731452736
>>> def multiplyVariable():
	return integer1 * integer2

>>> multiplyVariable()
3329.0063751232
>>> 