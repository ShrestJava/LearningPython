Python 3.9.7 (tags/v3.9.7:1016ef3, Aug 30 2021, 20:19:38) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> list_1 = ['1','2','3','4','5','6']
>>> print(list_1)
['1', '2', '3', '4', '5', '6']
>>> print(list_1[2])
3
>>> # prints the 3rd item on the list
>>> print(list_1[2:4])
['3', '4']
>>> # prints the 3rd item to the 5th item on the list
>>> integer = 100
>>> string = "three hundred"
>>> list_2 = [500,"six hundred"]
>>> list_3 = [integer,'200',string,'400',list_2]
>>> print(list_3)
[100, '200', 'three hundred', '400', [500, 'six hundred']]
>>> list_3.append(700)
>>> print(list_3)
[100, '200', 'three hundred', '400', [500, 'six hundred'], 700]
>>> del list_3[2]
>>> print(list_3)
[100, '200', '400', [500, 'six hundred'], 700]
>>> list_4 = [1,2,3,4]
>>> list_5 = [5,6,7,8]
>>> list_6 = list_4 + list_5
>>> print(list_6)
[1, 2, 3, 4, 5, 6, 7, 8]
>>> print(list_4 + list_5)
[1, 2, 3, 4, 5, 6, 7, 8]
>>> print(list_6 * 2)
[1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 8]
>>> # a tuple is a list that uses parentheses for example
>>> tuple_1 = (1, 2, 3, "Four", "Five")
>>> # the main difference between a tuple and a list is that a tuple cant change once you've created it
>>> # below this comment is how to replace a value in a list
>>> list_6[0] = "Hut!"
>>> print(list_6)
['Hut!', 2, 3, 4, 5, 6, 7, 8]
>>> 