Python 3.9.7 (tags/v3.9.7:1016ef3, Aug 30 2021, 20:19:38) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> favourite_sports_map = {'Shrest':'Basketball and Soccer','Ishanvi':'Catch & Throw','Srinivas':'Chess', 'Vineela':'Frisbee'}
>>> print(favourite_sports_map)
{'Shrest': 'Basketball and Soccer', 'Ishanvi': 'Catch & Throw', 'Srinivas': 'Chess', 'Vineela': 'Frisbee'}
>>> print(favourite_sports_map['Shrest'])
Basketball and Soccer
>>> del favourite_sports_map['Ishanvi']
>>> print(favourite_sports_map)
{'Shrest': 'Basketball and Soccer', 'Srinivas': 'Chess', 'Vineela': 'Frisbee'}
>>> favourite_sports_map['Shrest'] = 'Basketball, Soccer and Swimming'
>>> print(favourite_sports_map)
{'Shrest': 'Basketball, Soccer and Swimming', 'Srinivas': 'Chess', 'Vineela': 'Frisbee'}
>>> 