import turtle
 
t = turtle.Turtle()
for i in range(7):
   t.forward(100) 
   t.right(51.42) 
