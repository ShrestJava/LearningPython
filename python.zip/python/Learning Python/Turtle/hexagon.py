import turtle
 
t = turtle.Turtle()
for i in range(6):
   t.forward(100) #Assuming the side of a hexagon is 100 units
   t.right(60) #Turning the turtle by 60 degree
