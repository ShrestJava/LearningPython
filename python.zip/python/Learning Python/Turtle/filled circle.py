import turtle
tr = turtle.Turtle()
tr.fillcolor('black')
tr.begin_fill()
tr.circle(100)
tr.end_fill()
turtle.done()
