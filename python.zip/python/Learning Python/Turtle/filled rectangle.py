import turtle
tr = turtle.Turtle()
tr.fillcolor('orange')
tr.begin_fill()
for i in range(2):
    tr.forward(250)
    tr.right(90)
    tr.forward(150)
    tr.right(90)
tr.end_fill()
turtle.done()
