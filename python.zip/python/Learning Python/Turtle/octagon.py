import turtle
 
t = turtle.Turtle()
for i in range(8):
   t.forward(100)
   t.right(45)
