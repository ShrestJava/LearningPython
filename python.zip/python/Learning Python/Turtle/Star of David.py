import turtle
 
t = turtle.Turtle()
 
# first triangle for star
t.forward(100) # draw base
 
t.left(120)
t.forward(100)
 
t.left(120)
t.forward(100)
 
t.up()
t.right(150)
t.forward(50)
 
# second triangle for star
t.down()
t.right(90)
t.forward(100)
 
t.right(120)
t.forward(100)
 
t.right(120)
t.forward(100)
 
turtle.done()
