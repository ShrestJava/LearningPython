import turtle
 
t = turtle.Turtle()
 
t.forward(100) # draw base
 
t.left(90)
t.forward(100)
 
t.left(135)
t.forward(142)
 
turtle.done()
