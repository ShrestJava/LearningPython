import turtle
tr = turtle.Turtle()
tr.color('red')
style = ('courier',30,'italic')
tr.write('Welcome to Python Turtle',font=style,align='center')
tr.hideturtle()
turtle.done()
