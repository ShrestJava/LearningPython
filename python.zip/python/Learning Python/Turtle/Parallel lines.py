Python 3.9.7 (tags/v3.9.7:1016ef3, Aug 30 2021, 20:19:38) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import turtle
>>> t = turtle.Pen()
>>> # we can use t.up() to lift the pen off the page and t.down() to put the pen back onto the page
>>> t.backward(100)
>>> # the parameter in t.left(), t.right(), t.lt() and t.rt() is the angle for the pen to turn
>>> t.up()
>>> t.right(90)
>>> t.forward(20)
>>> t.left(90)
>>> t.down()
>>> t.forward(100)
>>> # the parameter in t.forward() or t.backward() is the amount of pixels to go forward or backward
>>> 