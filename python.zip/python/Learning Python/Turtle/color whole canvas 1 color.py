import turtle 
turtle.bgcolor("green")
turtle.done()
