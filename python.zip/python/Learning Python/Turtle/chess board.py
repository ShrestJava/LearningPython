import turtle
scr = turtle.Screen()
tr = turtle.Turtle()
def draw():
  for i in range(4):
    tr.forward(20)
    tr.left(90)
  tr.forward(20)
if __name__ == "__main__":
    scr.setup(600, 600)
    tr.speed(100)
    for i in range(8):
      tr.up()
      tr.setpos(0, 20*i)
      tr.down()
      for j in range(8):
        if(i + j)%2 == 0:
         col = 'black'
        else:
         col = 'white'
        tr.fillcolor(col)
        tr.begin_fill()
        draw()
        tr.end_fill()
      tr.hideturtle()
turtle.done()
