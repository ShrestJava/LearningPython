from turtle import Screen, Turtle
Cursor_Size = 20
scr = Screen()
scr.setup(600, 600) 
scr.setworldcoordinates(0, 0, 12, 24)
scr.bgcolor('black')
turtle = Turtle('square', visible=False)
turtle.penup()
turtle.speed(10)
turtle.color('black', 'red')
turtle.shapesize(25 / Cursor_Size, 50 / Cursor_Size, 5)
for y in range(24):
    turtle.setposition(-0.5 * (y % 2), y + 0.3)
    for x in range(13):
        turtle.stamp()
        turtle.forward(1)
scr.mainloop()
