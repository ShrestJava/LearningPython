import turtle
tr = turtle.Turtle()
list = ["violet","blue","red","green"]
tr.up()
tr.goto(200,0)
for i in range(4):
    tr.down()
    tr.begin_fill()
    tr.fillcolor(list[i])
    tr.circle(50)
    tr.end_fill()
    tr.up()
    tr.backward(100)
tr.hideturtle()
turtle.done()
