import turtle 
t = turtle.Turtle()
t.color("black")
t.begin_fill()
t.circle(130,180) # 1st parameter radius 2nd parameter how many degrees of the circle to draw
t.end_fill()
t.hideturtle()
turtle.done()
