import turtle 
tr = turtle.Turtle()
tr.color("black")
tr.shape("circle")
tr.begin_fill()
tr.shapesize(10,5,2)
tr.end_fill()
turtle.done()
