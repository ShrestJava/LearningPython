Python 3.9.7 (tags/v3.9.7:1016ef3, Aug 30 2021, 20:19:38) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> # for in range loop
>>> for x in range(0, 5):
	print('Hello')

	
Hello
Hello
Hello
Hello
Hello
>>> # counting numbers loop
>>> print(list(range(1, 15)))
[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
>>> # for in range counting loop
>>> for y in range(0, 10):
	print('hello %s' % y)

	
hello 0
hello 1
hello 2
hello 3
hello 4
hello 5
hello 6
hello 7
hello 8
hello 9
>>> # list loop
>>> List1 = ['Shrestajna', 'Vineela', 'Srinivas', 'Ishanvi', 'Anuratha', 'Surender', 'Bharath', 'Sravanthi', 'Shreenika', 'Padmaja', 'Tukaram', 'Nandini','Buchama', 'Narsaya', 'Shanthama']

>>> for i in List1:
	print(i)

	
Shrestajna
Vineela
Srinivas
Ishanvi
Anuratha
Surender
Bharath
Sravanthi
Shreenika
Padmaja
Tukaram
Nandini
Buchama
Narsaya
Shanthama
>>> NumbersList = [1,2,3]
>>> for a in NumbersList :
	print(a)
	print(a)

	
1
1
2
2
3
3
>>> #While loop
>>> num = 0
>>> while num < 5:
    num = num + 1
    print('num = ', num)

    
num =  1
num =  2
num =  3
num =  4
num =  5
>>> # Even Numbers While Loop
>>> x = 10
>>> l = 1
>>> i = l

>>> while i <= x:
    if i % 2 == 0:
        print(i)
    i = i + 1