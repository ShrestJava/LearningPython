Python 3.9.7 (tags/v3.9.7:1016ef3, Aug 30 2021, 20:19:38) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> # Random number 1 - 1,000,000 (1 million)
>>> import random
>>> print(random.randint(1, 1000000))
445771
>>> # i can make a function to do so also
>>> def randomnum():
	print(random.randint(1, 1000000))

	
>>> randomnum()
684091
>>> randomnum()
930672
>>> randomnum()
13797
>>> # picking a random item from a list
>>> import random
>>> desserts_list = ['Ice Cream','Cake','Brownie','Cookie','Candy','Chocolate']
>>> print(random.choice(desserts_list))
Candy
>>> # Shuffling lists
>>> import random
>>> desserts = ['Ice Cream','Cake','Brownie','Cookie','Candy','Chocolate']
>>> random.shuffle(desserts)
>>> print(desserts)
['Ice Cream', 'Candy', 'Chocolate', 'Cookie', 'Cake', 'Brownie']
>>> 