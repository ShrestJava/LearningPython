Python 3.9.7 (tags/v3.9.7:1016ef3, Aug 30 2021, 20:19:38) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> # Writing to a text file using Python
>>> test_write_file = open('C:\\Users\shres.DESKTOP-VG3FK7L\\Dropbox (Old)\\My PC (DESKTOP-VG3FK7L)\\Desktop\\test1.txt', 'w')
>>> # the 2nd parameter (w) tells Python that we want to write to the file not read it
>>> test_write_file.write('I am writing to a text file using Python')
40
>>> # the number forty that Python returns is the length of the value i wrote
>>> test_write_file.close()
>>> # test_write_file.close() means that we were telling Python that we were finished writing to the file now we have completed writing to a text file using python
>>> # now lets check it
>>> test_write_file = open('C:\\Users\shres.DESKTOP-VG3FK7L\\Dropbox (Old)\\My PC (DESKTOP-VG3FK7L)\\Desktop\\test1.txt')
>>> print(test_write_file.read())
I am writing to a text file using Python
>>> # Yay it worked!!!
>>> 