import sys


print('Enter a number')
num = str(sys.stdin.readline())
str1 = 'Your number is: '
str2 = str1 + num
print(str2)





######################################### or

inputstr = input('Enter a number: ')
