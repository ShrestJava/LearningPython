class Sidewalks(Inanimate):
    pass

class Animals(Animate):
    def breathe(self):
        print('Breathing')     
    def move(self):
          print('Moving')
    def eat_food(self):
          print('Eating Food')
    def drink_water(self):
          print('Drinking Water')
          
class Mammals(Animals):
    def feed_young_with_milk(self):
          print('Feeding Young')
    

class Giraffes(Mammals):
    def eat_leaves_from_trees(self):
          print('Eating Leaves')



          
   reginald = Giraffes()
   reginald.move()
   reginald.eat_leaves_from_trees()

   harold = Giraffes()
   harold.move()
