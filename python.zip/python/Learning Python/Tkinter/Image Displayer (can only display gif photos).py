from tkinter import *
tk = Tk()
canvas = Canvas(tk, width=100, height = 100)
canvas.pack()
my_img = PhotoImage(file='C:\\Users\\shres.DESKTOP-VG3FK7L\\Dropbox (Old)\\My PC (DESKTOP-VG3FK7L)\\Documents\\Shrest\\School and my google drive\\My Profile.gif')
canvas.create_image(0, 0, anchor = NW,image = my_img)
