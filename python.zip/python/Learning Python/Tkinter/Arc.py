Python 3.9.7 (tags/v3.9.7:1016ef3, Aug 30 2021, 20:19:38) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> from tkinter import *
>>> tk = Tk()
>>> canvas = Canvas(tk, width = 400, height = 400)
>>> canvas.pack()
>>> canvas.create_arc(10, 10, 200, 80, extent=45, style=ARC)
1
>>> canvas.create_arc(10, 80, 200, 160, extent=90, style=ARC)
2
>>> canvas.create_arc(10, 160, 200, 240, extent=135, style=ARC)
3
>>> canvas.create_arc(10, 240, 200, 320, extent=180, style=ARC)
4
>>> canvas.create_arc(10, 320, 200, 400, extent=359, style=ARC)
5
>>> 