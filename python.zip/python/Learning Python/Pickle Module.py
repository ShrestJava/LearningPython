Python 3.9.7 (tags/v3.9.7:1016ef3, Aug 30 2021, 20:19:38) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> # using the pickle module to save info
>>> import pickle
>>> game_data = {
   'player-position' : 'N23 E45',
   'pockets' : ['keys','pocket knife','polished stone'],
   'backpack' : ['rope','hammer','1 gal water','apple'],
   'money' : 158.50
   }
>>> save_file = open('C:\\Users\\shres.DESKTOP-VG3FK7L\\Dropbox (Old)\\My PC (DESKTOP-VG3FK7L)\\Documents\\Shrest\\Coding And Programming\\Files created with python\\player_info.dat', 'wb')
>>> # the parameter wb tels python to store the file in binary mode
>>> pickle.dump(game_data, save_file)
>>> save_file.close()
>>> ###############################################
>>> # how to unpickle objects and read pickled objects
>>> load_file = open('C:\\Users\\shres.DESKTOP-VG3FK7L\\Dropbox (Old)\\My PC (DESKTOP-VG3FK7L)\\Documents\\Shrest\\Coding And Programming\\Files created with python\\player_info.dat', 'rb')
>>> # the parameter rb means read binary file
>>> loaded_game_data = pickle.load(load_file)
>>> load_file.close()
>>> print(loaded_game_data)
{'player-position': 'N23 E45', 'pockets': ['keys', 'pocket knife', 'polished stone'], 'backpack': ['rope', 'hammer', '1 gal water', 'apple'], 'money': 158.5}
>>> 