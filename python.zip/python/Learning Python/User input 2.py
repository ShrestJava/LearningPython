Python 3.9.7 (tags/v3.9.7:1016ef3, Aug 30 2021, 20:19:38) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import sys
>>> userinput = sys.stdin.readline()
this is my input
>>> print("this is your input: %s" % userinput)
this is your input: this is my input

>>> # the code above was for user input
>>> # the code below is a bonus it is another way of printing to the screen
>>> import sys
>>> sys.stdout.write("hello world")
hello world11
>>> # the 11 after hello word is the amount of characters printed using the stdout method of printing
>>> 