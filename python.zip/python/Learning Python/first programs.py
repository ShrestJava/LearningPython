Python 3.9.7 (tags/v3.9.7:1016ef3, Aug 30 2021, 20:19:38) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> print("Hello World")
Hello World
>>> num_1 = 100
>>> print(num_1)
100
>>> 2+2
4
>>> 2*2
4
>>> 2/2
1.0
>>> 2-2
0
>>> num_2 = 1000
>>> num_1 + num_2
1100
>>> 20-3*4+(27/4.6)* num_1
594.9565217391305
>>> 100/60
1.6666666666666667
>>> # the % sign in equations means remainder so 5 % 2 would return the remainder of 5 / 2
>>> 5%2
1
>>> string_1 = "hi"
>>> print(string_1)
hi
>>> string_2 = '''He said, "Aren't can't shouldn't wouldn't. "'''
>>> print(string_2)
He said, "Aren't can't shouldn't wouldn't. "
>>> myscore= 1000
>>> message = 'I scored %s points'
>>> print(message % myscore)
I scored 1000 points
>>> num_3 = None
>>> print(num_3)
None
>>> Str_1 = '20'
>>> Str_1_converted_to_int = int(Str_1)
>>> print(Str_1_converted_to_int)
20
