# Python data type checking

string = "hhjhghagjk"
print(type(numChar))


# type casting _____(a data type)___ to string

StringNumChar = str(numChar)

# type casting _____(a data type)___ to integer

intNumChar = int(numChar)

# type casting _____(a data type)___ to float

StringNumChar = float(numChar)

# type casting _____(a data type)___ to boolean

StringNumChar = bool(numChar)