Python 3.9.7 (tags/v3.9.7:1016ef3, Aug 30 2021, 20:19:38) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> # Exec function(Execute)
>>> # The Excec function is like eval except that you can use it to run more complex programs
>>> # the difference between the two is that eval returns a value (something you can save in a variable) whereas exec does not.
>>> my_program = '''print(123)
print(456)'''
>>> exec(my_program)
123
456
>>> # variable functions int(), float(), str() ect
>>> # you can put your value as the parameters of the function and it converts the value into the variable of the name of the function
>>> num = 757
>>> num_converted_to_string = str(num)
>>> print(num_converted_to_string)
757
>>> # the min function returns the smallest item in a list, tuple or string
>>> # whereas the max function returns the largest item in a list, tuple or string
>>> # for a string the functions print ot the laste leter alphabetically and by the way python considers lowercase letters as higher than uppercase letters
>>> numbers = [5, 4, 10, 30, 27]
>>> print(max(numbers))
30
>>> # or
>>> string1 = 's,t,r,i,n,g,S,T,R,I,N,G,S'
>>> print(max(string1))
t
>>> # range function
>>> # the range function is mostly used in for loops the first two parameters are called the start and stop.
>>> for x in range(0,5) :
	print(x)

	
0
1
2
3
4
>>> # or
>>> print(list(range(0,5)))
[0, 1, 2, 3, 4]
>>> # you can also add a 3rd parameter called step if the step value is not included the number 1 is used by default
>>> count_by_two = list(range(0,30,2))
>>> print(count_by_two)
[0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28]
>>> # by the way variable functions can also be tuple, list or map
>>> # sum (sum) function returns the sum of its parameter(s) the parameter can be a list or a tuple
>>> list_of_numbers = list(range(0, 500, 50))
>>> print(list_of_numbers)
[0, 50, 100, 150, 200, 250, 300, 350, 400, 450]
>>> print(sum(list_of_numbers))
2250
>>> 