Python 3.9.7 (tags/v3.9.7:1016ef3, Aug 30 2021, 20:19:38) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> MyNumber = 200
>>> if MyNumber == 100 or 200 or 300 or None:
	print("Great Number!")

elif MyNumber < 100 :
	print("Sorry, your number is too small!")

elif MyNumber > 100 :
	print("Sorry, your number is too large!")

else:
	print("Wait what?       Huh?       Doesn't make any sense?")

	
Great Number!
>>> ######################################################################
>>> 